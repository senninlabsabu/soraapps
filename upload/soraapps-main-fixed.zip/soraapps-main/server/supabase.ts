import { createClient } from "@supabase/supabase-js";
import { config } from "./config.js";

// サーバーからだけ使う（service role）。ブラウザには鍵を渡さない
export const sb = createClient(config.supabaseUrl, config.supabaseServiceKey, {
  auth: { persistSession: false, autoRefreshToken: false }
});

